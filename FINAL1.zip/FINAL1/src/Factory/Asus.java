package Factory;

public class Asus implements Laptop {
    @Override
    public String getDescription() {
        return "Asus Laptop";
    }

    @Override
    public double getCost() {
        return 25000.0;
    }
    @Override
    public void repair() {

    }
}