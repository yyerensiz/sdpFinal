package Observer;

import java.util.Observable;

public class LaptopService extends Observable {
    public void notifyClient(String message) {
        setChanged();
        notifyObservers(message);
    }
}