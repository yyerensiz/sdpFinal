package Factory;

public class HPFactory implements LaptopFactory {
    @Override
    public Laptop createLaptop() {
        return new HP();
    }
}