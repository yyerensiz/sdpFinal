package Factory;

public class MSIFactory implements LaptopFactory {
    @Override
    public Laptop createLaptop() {
        return new MSI();
    }
}
