
import Adapter.LaptopRepair;
import Adapter.LaptopRepairAdapter;
import Decorator.*;
import Factory.Laptop;
import Factory.LaptopFactory;
import Observer.Client;
import Observer.LaptopService;
import Singleton.WarrantyService;
import Strategy.CardPayment;
import Strategy.CashPayment;
import Strategy.PaymentStrategy;
import Strategy.QRCodePayment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {
    private LaptopFactory laptopFactory;
    private Laptop laptop;
    private LaptopService laptopService;

    public Main() {
        setTitle("Laptop Maintenance Service");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JButton chooseLaptopButton = new JButton("Choose Laptop");
        JButton chooseServicesButton = new JButton("Choose Services");
        JButton okButton = new JButton("OK");
        JButton repairButton = new JButton("Repair");
        JButton warrantyService = new JButton("Warranty");
        JButton doneButton = new JButton("Done");
        JButton payButton = new JButton("Pay");

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(chooseLaptopButton);
        buttonPanel.add(chooseServicesButton);
        buttonPanel.add(okButton);
        buttonPanel.add(repairButton);
        buttonPanel.add(doneButton);
        buttonPanel.add(payButton);
        buttonPanel.add(warrantyService);

        add(buttonPanel, BorderLayout.CENTER);

        laptopService = new LaptopService();

        chooseLaptopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooseLaptop();
            }
        });

        chooseServicesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooseServices();
            }
        });

        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToEmployee();
            }
        });

        repairButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                repairLaptop();
            }
        });
        warrantyService.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                notifyGuarantee();
            }
        });

        doneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToClient();
                notifyClient();
            }
        });

        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                payAndShowMessage();
            }
        });


    }

    private void chooseLaptop() {
        String[] options = {"Acer", "Asus", "MacBook", "Lenovo", "MSI","HP","Huawei","Dell"};
        String selectedLaptop = (String) JOptionPane.showInputDialog(this, "Choose your laptop model:",
                "Choose Laptop", JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (selectedLaptop != null) {
            switch (selectedLaptop.toLowerCase()) {
                case "acer":
                    laptopFactory = new Factory.AcerFactory();
                    break;
                case "asus":
                    laptopFactory = new Factory.AsusFactory();
                    break;
                case "macbook":
                    laptopFactory = new Factory.MacBookFactory();
                    break;
                case "lenovo":
                    laptopFactory = new Factory.LenovoFactory();
                    break;
                case "msi":
                    laptopFactory = new Factory.MSIFactory();
                    break;
                case "hp":
                    laptopFactory = new Factory.HPFactory();
                    break;
                case "huawei":
                    laptopFactory = new Factory.HuaweiFactory();
                    break;
                case "dell":
                    laptopFactory = new Factory.DellFactory();
                    break;
                default:
                    showMessage("Invalid laptop model.");
                    return;
            }

            laptop = laptopFactory.createLaptop();
            showMessage("Laptop chosen: " + laptop.getDescription());
        }
    }

    private void chooseServices() {
        String[] options = {"Dust Cleaning - 2500tg", "Thermal Paste Replacement - 5000tg","Data recovery - 3500tg","Improvement modernization - 6000tg","Performance diagnostic - 4000tg","Software maintenance- 3000tg", "None - 0tg"};
        String selectedServices = (String) JOptionPane.showInputDialog(this, "Choose additional services:",
                "Choose Services", JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (selectedServices != null) {
            switch (selectedServices.toLowerCase()) {
                case "dust cleaning - 2500tg":
                    laptop = new DustCleaningDecorator(laptop);
                    break;
                case "thermal paste replacement - 5000tg":
                    laptop = new ThermalPasteReplacementDecorator(laptop);
                    break;
                case "data recovery - 3500tg":
                    laptop = new DataRecoveryDecorator(laptop);
                    break;
                case "improvement modernization - 6000tg":
                    laptop = new ImprovementModernizationDecorator(laptop);
                    break;
                case "performance diagnostic - 4000tg":
                    laptop = new PerformanceIssuesDecorator(laptop);
                    break;
                case "software maintenance- 3000tg":
                    laptop = new SoftwareMaintenanceDecorator(laptop);
                    break;
                case "none - 0tg":
                    laptop = new NoneDecorator(laptop);
                    break;
                default:
                    showMessage("Invalid service choice.");
                    return;
            }

            showMessage("Services chosen. Total cost: " + laptop.getCost()+"tg");
        }
    }

    private void switchToEmployee() {
        showMessage("Switching to employee mode.");
    }

    private void repairLaptop() {
        LaptopRepair laptopRepair = (LaptopRepair) laptop;
        LaptopRepairAdapter repairAdapter = new LaptopRepairAdapter(laptopRepair);
        showMessage("Repairing the laptop.");
        repairAdapter.repair();
    }
    private void notifyGuarantee() {
        laptopService.addObserver(new Client());
        showMessage("Your guarantee will be 12 month");
    }
    private void switchToClient() {
        showMessage("Switching back to client mode.");
    }

    private void notifyClient() {
        laptopService.addObserver(new Client());
        laptopService.notifyClient("Your laptop is done!");
    }

    private void payAndShowMessage() {
        showMessage("Total cost: " + laptop.getCost()+ "tg");
        String[] options = {"Card Payment", "Cash Payment", "QR Code Payment"};
        String selectedPaymentMethod = (String) JOptionPane.showInputDialog(this, "Choose payment method:",
                "Choose Payment Method", JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (selectedPaymentMethod != null) {
            PaymentStrategy paymentStrategy = null;

            switch (selectedPaymentMethod.toLowerCase()) {
                case "card payment":
                    paymentStrategy = new CardPayment();
                    break;
                case "cash payment":
                    paymentStrategy = new CashPayment();
                    break;
                case "QR code payment":
                    paymentStrategy = new QRCodePayment();
                    break;
                default:
                    showMessage("Invalid payment choice.");
                    return;
            }

            paymentStrategy.pay(laptop.getCost());
            showMessage("Goodbye! Come back again later!");}
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Main mainFrame = new Main();
                mainFrame.setSize(800, 600);
                mainFrame.setLocationRelativeTo(null);
                mainFrame.setVisible(true);
            }
        });
    }
}