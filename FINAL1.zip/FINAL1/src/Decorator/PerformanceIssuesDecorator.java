package Decorator;

import Factory.Laptop;

public class PerformanceIssuesDecorator extends AdditionalServiceDecorator {
    public PerformanceIssuesDecorator(Laptop laptop) {
        super(laptop);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Diagnostics of performance issues in laptop";
    }

    @Override
    public double getCost() {
        return super.getCost() + 4000;
    }

    @Override
    public void repair() {

    }
}
