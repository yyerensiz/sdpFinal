package Factory;

public class Huawei implements Laptop {
    @Override
    public String getDescription() {
        return "Huawei Laptop";
    }

    @Override
    public double getCost() {
        return 2500.0;
    }
    @Override
    public void repair() {

    }
}