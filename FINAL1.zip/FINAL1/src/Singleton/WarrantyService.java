package Singleton;

import Factory.Laptop;

public class WarrantyService {
    private static volatile WarrantyService instance;

    private WarrantyService() {
    }

    public static WarrantyService getInstance() {
        if (instance == null) {
            synchronized (WarrantyService.class) {
                if (instance == null) {
                    instance = new WarrantyService();
                }
            }
        }
        return instance;
    }

    public void provideWarranty() {
        System.out.println("Warranty service provided.");
    }

    public void tagAsBroken(Laptop laptop) {
        System.out.println("Tagging laptop as 'broken'");
    }
}