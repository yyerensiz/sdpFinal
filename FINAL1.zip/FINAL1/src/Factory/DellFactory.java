package Factory;

public class DellFactory implements LaptopFactory {
    @Override
    public Laptop createLaptop() {
        return new Dell();
    }
}