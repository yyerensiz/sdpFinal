package Factory;

public class HP implements Laptop {
    @Override
    public String getDescription() {
        return "HP Laptop";
    }

    @Override
    public double getCost() {
        return 30000.0;
    }
    @Override
    public void repair() {

    }
}