package Decorator;

import Factory.Laptop;

public class NoneDecorator extends AdditionalServiceDecorator {
    public NoneDecorator(Laptop laptop) {
        super(laptop);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", None";
    }

    @Override
    public double getCost() {
        return super.getCost() + 0;
    }

    @Override
    public void repair() {

    }
}