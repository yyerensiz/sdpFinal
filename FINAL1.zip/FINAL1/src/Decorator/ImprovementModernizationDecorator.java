package Decorator;

import Factory.Laptop;

public class ImprovementModernizationDecorator extends AdditionalServiceDecorator {
    public ImprovementModernizationDecorator(Laptop laptop) {
        super(laptop);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Installation of additional components, such as SSD to increase the speed of the laptop, increase the amount of RAM, etc.";
    }

    @Override
    public double getCost() {
        return super.getCost() + 6000;
    }

    @Override
    public void repair() {

    }
}
