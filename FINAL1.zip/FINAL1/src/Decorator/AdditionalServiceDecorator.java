package Decorator;

import Factory.Laptop;
public abstract class AdditionalServiceDecorator implements Laptop {
    private Laptop laptop;

    public AdditionalServiceDecorator(Laptop laptop) {
        this.laptop = laptop;
    }

    @Override
    public String getDescription() {
        return laptop.getDescription();
    }

    @Override
    public double getCost() {
        return laptop.getCost();
    }
}