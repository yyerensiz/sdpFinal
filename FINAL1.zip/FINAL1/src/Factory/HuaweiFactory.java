package Factory;

public class HuaweiFactory implements LaptopFactory {
    @Override
    public Laptop createLaptop() {
        return new Huawei();
    }
}