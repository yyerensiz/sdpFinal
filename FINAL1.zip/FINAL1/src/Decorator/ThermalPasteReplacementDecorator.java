package Decorator;
import Factory.Laptop;
public class ThermalPasteReplacementDecorator extends AdditionalServiceDecorator {
    public ThermalPasteReplacementDecorator(Laptop laptop) {
        super(laptop);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Thermal Paste Replacement";
    }

    @Override
    public double getCost() {
        return super.getCost() + 5000;
    }

    @Override
    public void repair() {

    }
}