package Decorator;

import Factory.Laptop;

public class DataRecoveryDecorator extends AdditionalServiceDecorator {
    public DataRecoveryDecorator(Laptop laptop) {
        super(laptop);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Data recovery from damaged hard drives or other storage media";
    }

    @Override
    public double getCost() {
        return super.getCost() + 3500;
    }

    @Override
    public void repair() {

    }
}
