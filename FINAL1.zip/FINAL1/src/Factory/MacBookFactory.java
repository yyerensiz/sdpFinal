package Factory;

public class MacBookFactory implements LaptopFactory {
    @Override
    public Laptop createLaptop() {
        return new MacBook();
    }
}