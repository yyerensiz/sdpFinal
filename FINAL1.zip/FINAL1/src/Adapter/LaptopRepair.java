package Adapter;

public interface LaptopRepair {
    void repair();
}