package Factory;

public class Lenovo implements Laptop {
    @Override
    public String getDescription() {
        return "Lenovo Laptop";
    }

    @Override
    public double getCost() {
        return 20000.0;
    }
    @Override
    public void repair() {

    }
}