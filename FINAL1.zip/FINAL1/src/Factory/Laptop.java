package Factory;

public interface Laptop extends Adapter.LaptopRepair {
    String getDescription();
    double getCost();
}