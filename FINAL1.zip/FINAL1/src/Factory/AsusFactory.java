package Factory;

public class AsusFactory implements LaptopFactory {
    @Override
    public Laptop createLaptop() {
        return new Asus();
    }
}