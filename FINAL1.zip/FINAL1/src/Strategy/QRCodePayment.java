package Strategy;

public class QRCodePayment implements PaymentStrategy {
    @Override
    public void pay(double amount) {
        System.out.println("Paid with QR Code: " + amount+"tg");
    }
}