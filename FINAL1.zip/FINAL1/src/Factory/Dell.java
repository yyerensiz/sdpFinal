package Factory;

public class Dell implements Laptop {
    @Override
    public String getDescription() {
        return "Dell Laptop";
    }

    @Override
    public double getCost() {
        return 20500.0;
    }
    @Override
    public void repair() {

    }
}
