package Factory;

public interface LaptopFactory {
    Laptop createLaptop();
}