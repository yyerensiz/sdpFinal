package Factory;

public class MacBook implements Laptop {
    @Override
    public String getDescription() {
        return "MacBook Laptop";
    }

    @Override
    public double getCost() {
        return 40000.00;
    }
    @Override
    public void repair() {

    }
}