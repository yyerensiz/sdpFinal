package Factory;

public class Acer implements Laptop {
    @Override
    public String getDescription() {
        return "Acer Laptop";
    }

    @Override
    public double getCost() {
        return 20000.0;
    }

    @Override
    public void repair() {

    }
}