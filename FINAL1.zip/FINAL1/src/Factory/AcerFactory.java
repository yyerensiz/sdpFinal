package Factory;

public class AcerFactory implements LaptopFactory {
    @Override
    public Laptop createLaptop() {
        return new Acer();
    }
}
