package Decorator;

import Factory.Laptop;

public class DustCleaningDecorator extends AdditionalServiceDecorator {
    public DustCleaningDecorator(Laptop laptop) {
        super(laptop);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Dust Cleaning";
    }

    @Override
    public double getCost() {
        return super.getCost() + 2500;
    }

    @Override
    public void repair() {

    }
}