package Decorator;

import Factory.Laptop;

public class SoftwareMaintenanceDecorator extends AdditionalServiceDecorator {
    public SoftwareMaintenanceDecorator(Laptop laptop) {
        super(laptop);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Installing and configuring the operating system, updating drivers, removing malware and viruses.";
    }

    @Override
    public double getCost() {
        return super.getCost() + 3000;
    }

    @Override
    public void repair() {

    }
}
