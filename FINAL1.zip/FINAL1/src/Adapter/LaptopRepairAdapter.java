package Adapter;

public class LaptopRepairAdapter implements LaptopRepair {
    private LaptopRepair brokenLaptop;

    public LaptopRepairAdapter(LaptopRepair brokenLaptop) {
        this.brokenLaptop = brokenLaptop;
    }

    @Override
    public void repair() {
        System.out.println("Using toolkit to repair Laptop and Additional services:" + brokenLaptop.getClass().getSimpleName());
        brokenLaptop.repair();
    }
}