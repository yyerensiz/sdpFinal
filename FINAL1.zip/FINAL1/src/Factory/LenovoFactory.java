package Factory;

public class LenovoFactory implements LaptopFactory {
    @Override
    public Laptop createLaptop() {
        return new Lenovo();
    }
}